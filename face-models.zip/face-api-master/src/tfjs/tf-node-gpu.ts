export * from '@tensorflow/tfjs-node-gpu';
export { version } from '../../dist/tfjs.version.js';
